<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

class plgSystemBlankPlugin extends JPlugin {
	
	function plgBlankPlugin( &$subject, $params ) {
		parent::__construct( $subject, $params );
	}
	
	function onBeforeRender() {
		$app = JFactory::getApplication();
		$admin = $app->isAdmin();
		
		if(!$admin) {
			$doc =& JFactory::getDocument();
			$doc->addScript(JURI::root()."plugins/system/blankplugin/assets/js/dropbox.js");
		}
	}
}
?>