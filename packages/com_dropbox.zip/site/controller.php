<?php

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

class DropBoxComponentController extends JController {

    public function display($cachable = false, $urlparams = false) {
        $view = JRequest::get('view');
        $task = JRequest::get('task');
        $layout = JRequest::getVar('layout');

        switch ($view) {
            case 'sync':
                break;
            default:
                JRequest::setVar('view', 'default');
        }

        return parent::display($cachable, $urlparams);
    }

}
