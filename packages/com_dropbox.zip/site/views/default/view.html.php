<?php
// No direct access
defined('_JEXEC') or die;

include_once(COMPONENT_PATH.DS."dropbox.inc.php");

jimport('joomla.application.component.view');

class DropBoxComponentViewDefault extends JView {

    function display($tpl = null) {
        $app = JFactory::getApplication();

        $this->addToolBar();
        /* $params = $app->getParams();

          $menus	= $app->getMenu();
          $menu	= $menus->getActive();

          if (is_object($menu)) {
          $menu_params = new JRegistry;
          $menu_params->loadJSON($menu->params);
          if (!$menu_params->get('page_title')) {
          $params->set('page_title',	JText::_('Blank Component'));
          }
          }
          else {
          $params->set('page_title',	JText::_('Blank Component'));
          }

          $title = $params->get('page_title');
          if ($app->getCfg('sitename_pagetitles', 0)) {
          $title = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $title);
          }
          $this->document->setTitle($title);

          if ($params->get('menu-meta_description'))
          {
          $this->document->setDescription($params->get('menu-meta_description'));
          }

          if ($params->get('menu-meta_keywords'))
          {
          $this->document->setMetadata('keywords', $params->get('menu-meta_keywords'));
          }

          if ($params->get('robots'))
          {
          $this->document->setMetadata('robots', $params->get('robots'));
          }

          $this->assignRef('params',		$params); */

        $key = '47ux15x0sz9zzqw';
        $secret = 'r85z6ybiyshdet6';

        // Check whether to use HTTPS and set the callback URL
        $dropboxHelper = new DropboxHelper($key, $secret);
//            $protocol = (!empty($_SERVER['HTTPS'])) ? 'https' : 'http';
//            $callback = $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
//
//            $encrypter = new \Dropbox\OAuth\Storage\Encrypter('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
//            $storage = new FileStorage($encrypter);
//            $OAuth = new \Dropbox\OAuth\Consumer\Curl($key, $secret, $storage, $callback);
//            $dropbox = new \Dropbox\API($OAuth);

        $localfiles = $dropboxHelper->getLocalFileListing();
        $remoteobjects = $dropboxHelper->fetchFiles("");
        $remotefiles = $dropboxHelper->getRemoteFileListing($remoteobjects);
        ?>
        <table class="adminlist">
    <thead>
        <tr>
            <th width="1%">Status</th>
            <th>Filename</th>
            <th>Folder</th>
        </tr>
    </thead>
    <tbody>
        <?php
            foreach($remotefiles as $file):
                $pi = pathinfo($file);
        ?>
        <tr>
            <td class="jgrid center"><span class="state publish"></span></td>
            <td><?php echo $pi['basename']; ?></td>
            <td><?php echo $pi['dirname']; ?></td>
        </tr>
        <?php
            endforeach;
        ?>
    </tbody>
</table>
<?php

        //parent::display($tpl);
    }
    
    protected function addToolBar() {
        JToolBarHelper::title('DropBox Sync');
        JToolBarHelper::addNew('sync', 'Sync');
        JToolBarHelper::preferences('com_dropbox');
    }

}
