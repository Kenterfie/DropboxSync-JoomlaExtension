<?php

// No direct access
defined('_JEXEC') or die;

include_once(COMPONENT_PATH.DS."dropbox.inc.php");

define('DROPBOX_LOCK', JOOMLA_TEMP . '/dropbox.lock');

jimport('joomla.html.parameter');
jimport('joomla.application.component.view');

class DropBoxComponentViewSync extends JView {

    function display($tpl = null) {
        $app = JFactory::getApplication();

        $time = time();
        $lasttime = 0;

        $response = array("removed" => 0, "added" => 0, "updated" => 0, "locked" => 0, "time" => 0);

        // read last update time
        $fp = fopen(DROPBOX_LOCK, "r");
        if ($fp) {
            $lasttime = fgets($fp);
            if (strlen($lasttime) == 0)
                $lasttime = 0;
            fclose($fp);
        }

        // reopen file to get write access
        if ($time - $lasttime > 15) {
            $fp = fopen(DROPBOX_LOCK, "w+");
        }
        if (flock($fp, LOCK_EX | LOCK_NB)) { // get lock
            $response['locked'] = true;

            $lasttime = $time;
            fputs($fp, $lasttime);

            // Set your consumer key, secret and callback URL
            $key = '47ux15x0sz9zzqw';
            $secret = 'r85z6ybiyshdet6';

            // Check whether to use HTTPS and set the callback URL
            $dropboxHelper = new DropboxHelper($key, $secret);
//            $protocol = (!empty($_SERVER['HTTPS'])) ? 'https' : 'http';
//            $callback = $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
//
//            $encrypter = new \Dropbox\OAuth\Storage\Encrypter('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
//            $storage = new FileStorage($encrypter);
//            $OAuth = new \Dropbox\OAuth\Consumer\Curl($key, $secret, $storage, $callback);
//            $dropbox = new \Dropbox\API($OAuth);

            $localfiles = $dropboxHelper->getLocalFileListing();
            $remoteobjects = $dropboxHelper->fetchFiles("");
            $remotefiles = $dropboxHelper->getRemoteFileListing($remoteobjects);

            /* foreach($remotefiles as $file) {
              echo $file.'<br />';
              } */

            $filters = array("thumbs", "preview");

            function contains($str, $arr) {
                foreach ($arr as $filter) {
                    if (stripos($str, $filter) != 0) {
                        return true;
                    }
                }
                return false;
            }

            $removeFiles = array_diff($localfiles, $remotefiles);
            foreach ($removeFiles as $file) {
                $path = dirname($file);
                if (contains($path, $filters))
                    continue;
                JFile::delete(DROPBOX_FOLDER . $file);
                //echo $file.' removed<br />';
                $response['removed']++;
            }

            foreach ($localfiles as $file) {
                
            }

            foreach ($remoteobjects as $file) {
                //echo $file->path.'<br />';
                $outFile = false;
                if (!JFolder::exists(DROPBOX_FOLDER . dirname($file->path))) {
                    JFolder::create(DROPBOX_FOLDER . dirname($file->path));
                    //echo dirname($file->path).' created<br />';
                }
                if (!JFile::exists(DROPBOX_FOLDER . $file->path)) {
                    $temp = tmpfile();
                    $dropbox->getFile($file->path, $temp);
                    JFile::move($temp, DROPBOX_FOLDER . $file->path);
                    //echo $file->path." downloaded<br />";
                    $response['added']++;
                } else {
                    //echo " exist<br />";
                }
            }

            /* $params = &JComponentHelper::getParams('com_blankcomponent');
              print_r($params->toArray()); */

            /* $params = $app->getParams();

              $menus	= $app->getMenu();
              $menu	= $menus->getActive();

              if (is_object($menu)) {
              $menu_params = new JRegistry;
              $menu_params->loadJSON($menu->params);
              if (!$menu_params->get('page_title')) {
              $params->set('page_title',	JText::_('Blank Component'));
              }
              }
              else {
              $params->set('page_title',	JText::_('Blank Component'));
              }

              $title = $params->get('page_title');
              if ($app->getCfg('sitename_pagetitles', 0)) {
              $title = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $title);
              }
              $this->document->setTitle($title);

              if ($params->get('menu-meta_description'))
              {
              $this->document->setDescription($params->get('menu-meta_description'));
              }

              if ($params->get('menu-meta_keywords'))
              {
              $this->document->setMetadata('keywords', $params->get('menu-meta_keywords'));
              }

              if ($params->get('robots'))
              {
              $this->document->setMetadata('robots', $params->get('robots'));
              }

              $this->assignRef('params',		$params); */
            $doc = $this->document;
            JRequest::setVar('tmpl', 'component');
            $doc->setTitle("Sync");
            $doc->setMimeEncoding('application/json');
            JResponse::setHeader('Content-Disposition', 'attachment;filename="' . $this->getName() . '.json"');

            flock($fp, LOCK_UN);
            fclose($fp);
        } else {
            //print('not locked');
            $response['locked'] = false;
        }
        $response['time'] = date('Y-m-d H:i:s', $lasttime);
        echo json_encode($response);
        $app->close();
    }

}
