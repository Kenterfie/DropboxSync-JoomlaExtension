<?php
/**
* Author:	Omar Muhammad
* Email:	admin@omar84.com
* Website:	http://omar84.com
* Component:Blank Component
* Version:	1.7.0
* Date:		21/9/2011
* copyright	Copyright (C) 2011 http://omar84.com. All Rights Reserved.
* @license	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
**/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

define('COMPONENT_PATH', JPATH_SITE.DS.'components'.DS.'com_dropbox');

// Instantiate the required Dropbox objects
// Retrieve the account information
//$accountInfo = $dropbox->accountInfo();

// Dump the output
//var_dump($accountInfo);

// Get the metadata for the file/folder specified in $path
//$metaData = $dropbox->metaData('');

// Dump the output
//var_dump($metaData["body"]);

//$metaData = $dropbox->metaData('/2010-06-08');
//var_dump($metaData["body"]);

$app = JFactory::getApplication();
$admin = $app->isAdmin();
//echo($dstPath);

/*$task = JRequest::getCmd('task');
if($task == "sync") {
    
    echo "sync";
    exit();
}*/

if(false /*$admin==1*/) {
    $localfiles = getLocalFileListing();
    $remoteobjects = fetchFiles($dropbox, "");
    $remotefiles = getRemoteFileListing($remoteobjects);
    
    //echo 'local => ';
    //print_r($localfiles);
    //echo 'remote => ';
    //print_r($remotefiles);
    
    //echo 'diff local.remote [remove] => ';
    $removeFiles = array_diff($localfiles, $remotefiles);
    foreach($removeFiles as $file) {
        JFile::delete(DROPBOX_FOLDER.$file);
        //echo $file.' removed<br />';
    }
    
    //echo 'diff remote.local => ';
    //print_r(array_diff($remotefiles, $localfiles));
    
    /*foreach($remotefiles as $file) {
        echo $file->path.'<br />';
        $outFile = false;
        if(!JFolder::exists(DROPBOX_FOLDER.dirname($file->path))) {
            JFolder::create(DROPBOX_FOLDER.dirname($file->path));
            echo dirname($file->path).' created<br />';
        }
        if(!JFile::exists(DROPBOX_FOLDER.$file->path)) {
            $dropbox->getFile($file->path, DROPBOX_FOLDER.$file->path);
            echo " downloaded<br />";
        } else {
            echo " exist<br />";
        }
    }*/
    //JToolBarHelper::title(   JText::_( 'DropBox Sync' ), 'generic.png' );
    //JToolBarHelper::addNewX('sync', 'Sync');
    //JToolBarHelper::preferences('com_blank');
?>
<table class="adminlist">
    <thead>
        <tr>
            <th width="1%">Status</th>
            <th>Filename</th>
            <th>Folder</th>
        </tr>
    </thead>
    <tbody>
        <?php
            foreach($remotefiles as $file):
                $pi = pathinfo($file);
        ?>
        <tr>
            <td class="jgrid center"><span class="state publish"></span></td>
            <td><?php echo $pi['basename']; ?></td>
            <td><?php echo $pi['dirname']; ?></td>
        </tr>
        <?php
            endforeach;
        ?>
    </tbody>
</table>
<?php
} else {
    // Create the controller
    $controller = JController::getInstance('DropBoxComponent');

    // Perform the Request task
    $controller->execute(JRequest::getCmd('task'));

    // Redirect if set by the controller
    $controller->redirect();
}
?>