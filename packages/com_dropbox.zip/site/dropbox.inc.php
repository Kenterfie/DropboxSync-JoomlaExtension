<?php

define('DROPBOX_FOLDER', JPATH_SITE."/images/dropbox");
define('JOOMLA_TEMP', JPATH_SITE."/tmp");

require_once(COMPONENT_PATH.DS."dropbox".DS."OAuth".DS."Consumer".DS."ConsumerAbstract.php");
require_once(COMPONENT_PATH.DS."dropbox".DS."OAuth".DS."Consumer".DS."Curl.php");
require_once(COMPONENT_PATH.DS."dropbox".DS."OAuth".DS."Storage".DS."Encrypter.php");
require_once(COMPONENT_PATH.DS."dropbox".DS."OAuth".DS."Storage".DS."StorageInterface.php");
//require_once(JPATH_COMPONENT.DS."dropbox".DS."OAuth".DS."Storage".DS."Session.php");
require_once(COMPONENT_PATH.DS."dropbox".DS."Exception.php");
require_once(COMPONENT_PATH.DS."dropbox".DS."API.php");
require_once(COMPONENT_PATH.DS."JoomlaStorage.php");

class DropboxHelper {
    private $dropbox;
    function __construct($key, $secret) {
        // Check whether to use HTTPS and set the callback URL
        $protocol = (!empty($_SERVER['HTTPS'])) ? 'https' : 'http';
        $callback = $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        $encrypter = new \Dropbox\OAuth\Storage\Encrypter('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
        $storage = new JoomlaStorage($encrypter);
        $OAuth = new \Dropbox\OAuth\Consumer\Curl($key, $secret, $storage, $callback);
        $this->dropbox = new \Dropbox\API($OAuth);
    }
    function fetchFiles($path) {
        $files = array();
        $metaData = $this->dropbox->metaData($path);
        //var_dump($metaData);
        foreach($metaData["body"]->contents as $file) {
            if($file->is_dir && !empty($file->path)) {
                //var_dump($file->path);
                //$this->fetchFiles($file->path);
                $files = array_merge($files, $this->fetchFiles($file->path));
            } else {
                $files[] = $file;
            } 
        }
        return $files;
    }
    function getLocalFileListing() {
        $files = JFolder::files(DROPBOX_FOLDER, $filter = '.', true, true);
        foreach($files as &$file) {
            $file = substr($file, strlen(DROPBOX_FOLDER));
            //echo $file.'<br />';
        }
        return $files;
    }
    function getRemoteFileListing($objects) {
        $files = array();
        foreach($objects as $object) {
            $files[] = $object->path;
        }
        return $files;
    }
}

function sync($dropbox) {
    
}

?>
